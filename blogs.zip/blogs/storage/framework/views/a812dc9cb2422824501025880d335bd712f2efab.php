<?php $__env->startSection('title', 'Blogs'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Blogs</h1>

    <h2><a href="<?php echo e(route('dashboard')); ?>">Back to Dashboard</a></h2>


    <a href="<?php echo e(route('admin.blogs.create')); ?>">Create New Blog</a>

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($blog->id); ?></td>
                <td><?php echo e($blog->title); ?></td>
                <td><?php echo e($blog->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\blogs-project\blogs\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>