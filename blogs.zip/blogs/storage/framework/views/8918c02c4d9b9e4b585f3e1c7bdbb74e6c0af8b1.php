<?php $__env->startSection('title', 'Create Blog'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create New Blog</h1>

    <form action="<?php echo e(route('admin.blogs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
        </div>
        <div>
            <label for="content">Content:</label>
            <textarea id="content" name="content" rows="4" required></textarea>
        </div>
        <div>
            <label>Categories:</label><br>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>">
                <label><?php echo e($category->name); ?></label><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="submit">Create</button>
    </form>
<?php $__env->stopSection(); ?>



<h2><a href="<?php echo e(route('admin.blogs.index')); ?>">Back to all blogs</a></h2>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\blogs-project\blogs\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>