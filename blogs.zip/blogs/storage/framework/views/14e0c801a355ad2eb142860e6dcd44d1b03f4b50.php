<?php $__env->startSection('title', 'Create Category'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create New Category</h1>

    <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <button type="submit">Create</button>
    </form>
<?php $__env->stopSection(); ?>


<h2><a href="<?php echo e(route('admin.categories.index')); ?>">Back to all categories</a></h2>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\blogs-project\blogs\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>