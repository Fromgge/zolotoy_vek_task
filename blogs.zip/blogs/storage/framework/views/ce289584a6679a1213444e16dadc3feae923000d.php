<?php if($blogs->count()): ?>
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('categories._parts._blog_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
        <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-6">
                <div class="ml-4 text-lg leading-2 font-semibold text-gray-900 dark:text-white" style="color: Red">
                    <label>
                        Result not found
                    </label>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\WORK\blogs-project\blogs\resources\views/categories/_parts/_search.blade.php ENDPATH**/ ?>