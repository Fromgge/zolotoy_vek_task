<?php $__env->startSection('title', 'Edit Category'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit Blog</h1>
    <h2><a href="<?php echo e(route('admin.categories.index')); ?>">Back to all categories</a></h2>

    <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo e($category->name); ?>" required>
        </div>
        <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\blogs-project\blogs\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>